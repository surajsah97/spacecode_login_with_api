import React from 'react'

const Home = () => {
    return (
        <div>
            hello home
        </div>
    )
}
export default Home