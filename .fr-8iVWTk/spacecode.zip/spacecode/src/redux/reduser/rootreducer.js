import Signin from "./reducer";
import { combineReducers } from "redux";
const Rootreducer=combineReducers({
    Signin
})
export default Rootreducer;