import { Grid } from '@material-ui/core';
import React from 'react'

const Image = () => {
    return (
        <div>
            {/* <Grid
        //   className={classes.add}
        style={{background:"#281736", display:"flex",
        justifyContent:"center",borderRadius:"10px 10px 0px 0px"}}
         
          p={1}
        > */}
          <img src="./image/1.png" alt="lebal" width="250vw"/>
        {/* </Grid> */}
        </div>
    )
}
export default Image;